# AutoSense – AI-Powered Vehicle Diagnosis & Repair Assistant

Diagnose. Remember. Find help.

## Features
- Vehicle details, symptom text, photo and sound-clip inputs
- Diagnosis with likely cause, confidence, priority, affected components and cost range (INR)
- Mechanic search via Google Maps
- Repair history and service reminders (saved in browser localStorage)

## Run locally
- Open `index.html` in a browser, or run `python -m http.server 8000` and visit http://localhost:8000

## Roadmap
- Replace the rule-based `diagnose()` in `app.js` with a backend (FastAPI) calling YOLO, an audio classifier and an LLM API
- Add login and a database (PostgreSQL / Firebase)
- Add email / push service reminders

## Author
Atsaya VK – CSE A, Rathinam Technical Campus

> AI supports diagnosis – it never replaces a qualified mechanic.
